package com.example.bluetoothshenenagans4;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class BlueHandler {
    private final UUID nUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //this is an android thing just leave it
    private String addr = null;
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private BluetoothDevice hc05 = null;
    private OutputStream out = null;
    private InputStream in = null;
    private msgHandler bitBlaster;
    private byte [] reads;

    BlueHandler (String addr, msgHandler bitBlaster) throws IOException{
        setBtAdapter();
        setAddr(addr);
        setDevice();
        setBtSocket();
        setOut();
        setIn();
        setReads();
        this.bitBlaster = bitBlaster;
    }

    public int isAvailable(){
        int temp;
        try {
            temp = in.available();
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }
        return temp;
    }

    public String startConnection() {
        int attempt = 0;
        do {
            try {
                this.btSocket.connect();
            } catch (IOException e) {
                e.printStackTrace();
                return "Error 1";
            }
        } while (!btSocket.isConnected() && attempt < 3); //atempts to connect 3 times to the bluetooth

        if (this.btSocket.isConnected()){
            return "Connected";
        } else {
            return "Not Connected";
        }
    }

    public boolean btWrite (byte bytes[], String instruction){
        try {
            this.out.write(bytes, 0, bitBlaster.getSize(instruction));
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public String btRead() {
        int counter = 0;
        int counter2 = 0;
        try {
            counter = in.read();
            counter2 = in.read();
            if (counter == counter2){
                bitBlaster.int2Bytes(counter, reads, 1, 0);
                bitBlaster.int2Bytes(counter, reads, 1, 1);
                for(int i=2; i<counter; i++){
                    bitBlaster.int2Bytes(in.read(), reads, 1, i);
                }
            } else {
                return bitBlaster.readInstruction(reads, 0);
            }

        } catch (IOException e) {
            e.printStackTrace();
            return "Error 3";
        }

        return bitBlaster.readInstruction(reads,counter);
    }

    public boolean endConnection(){
        try {
            this.btSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    //-------------------------------------Setters
    public void setBtAdapter() {
        this.btAdapter = BluetoothAdapter.getDefaultAdapter();
    }
    public void setBtSocket() throws IOException {
        this.btSocket = this.hc05.createInsecureRfcommSocketToServiceRecord(nUUID);
    }
    public void setDevice(){
        this.hc05 = btAdapter.getRemoteDevice(this.addr);
    }
    public void setOut() throws IOException {
        out = this.btSocket.getOutputStream();
    }
    public void setAddr(String addr) {
        this.addr = new String(addr);
    }
    public void setIn() throws IOException{
        in = this.btSocket.getInputStream();
    }
    public void setReads() {
        reads = new byte [256];
    }

    //---------------------------------------Getters
    public BluetoothAdapter getBtAdapter() {
        return btAdapter;
    }
    public BluetoothSocket getBtSocket() {
        return btSocket;
    }
    public BluetoothDevice getHc05() {
        return hc05;
    }
    public UUID getnUUID() {
        return nUUID;
    }
    public String getAddr() {
        return new String(this.addr);
    }
    public InputStream getIn() {return in;}
    public OutputStream getOut() {return out;}
    public msgHandler getBitBlaster() {return bitBlaster;}
    public byte[] getReads() {
        return reads;
    }

    @Override
    public String toString() {
    String temp = new String("Adress: " + hc05.getAddress() + ",\nName: " + this.hc05.getName() + ",\nConnected? " + btSocket.isConnected());
    return temp;
    }

    @Override
    public boolean equals(Object o){
        if (o.equals(this)){
            return true;
        }
        if (o.getClass() != this.getClass()) {
            return false;
        }
        return this.toString().equals(o.toString());
    }
}
